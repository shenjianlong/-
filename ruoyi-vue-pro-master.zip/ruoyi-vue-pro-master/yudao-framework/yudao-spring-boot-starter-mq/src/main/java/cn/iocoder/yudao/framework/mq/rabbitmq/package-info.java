/**
 * 消息队列，基于 RabbitMQ 提供
 */
package cn.iocoder.yudao.framework.mq.rabbitmq;
