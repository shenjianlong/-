/**
 * 脱敏组件：支持 JSON 返回数据时，将邮箱、手机等字段进行脱敏
 */
package cn.iocoder.yudao.framework.desensitize;
